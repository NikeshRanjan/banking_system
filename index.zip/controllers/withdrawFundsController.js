const moment = require('moment');
const withdrawManager = require('../data/managers/withdrawFundsManager');

exports.withdrawFundsController = async (req, res) => {
  try {
    const id = req.params.id;
    let { amount } = req.body;

    const updatedCustomer = await withdrawManager.withdrawFunds(id, amount);

    const createdAt = moment(updatedCustomer.createdAt).format('lll');
    const modifiedAt = moment(updatedCustomer.updatedAt).format('lll');
    const dobFormatted = moment(updatedCustomer.dob).format('ll');

    res.status(200).json({
      success: true,
      data: {
        customer: updatedCustomer,
        createdAt,
        modifiedAt,
        dob: dobFormatted,
      },
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};
