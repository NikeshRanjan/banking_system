const moment = require('moment');
const customerDisplayManager = require('../data/managers/customerDisplayManager')


exports.customerDisplayController = async (req, res) => {
  try {
    const searchQuery = {
      _id: req.params.id
    }

    const customerData = await customerDisplayManager.getCustomerById(searchQuery);
    
    const createdAt = moment(customerData.createdAt).format('lll');
    const modifiedAt = moment(customerData.updatedAt).format('lll');
    const dob = moment(customerData.dob).format('ll');

    // const allCustomers = await customerDisplayManager.displayCustomerList(id);

    res.render('customer', {
      // allCustomers,
      customerData,
      createdAt,
      modifiedAt,
      dob,
    });
  } catch (error) {
    console.error(error);
    res.json({ message: 'Server Error!' });
  }
};
