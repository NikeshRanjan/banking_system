const transctionManager = require('../data/managers/displayTransctionsManager');

module.exports.displayTransction = async (req, res) => {
    const id = req.params.id;

    const displayedTransctions = await transctionManager.transctionManager(id)
    res.status(200).json({success: true, data: displayedTransctions});
};
