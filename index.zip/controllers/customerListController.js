const customerListManager = require('../data/managers/customerListManager');

module.exports.customerList = async (req, res) => {
    try {
        const allCustomers = await customerListManager.customerList({})
        res.status(200).json({ success: true, data: allCustomers });
    }
    catch (error) {
        console.error(error);
        res.json({ message: 'Server Error!' });
    }
};