const Customer = require("../models/customerModel");

module.exports.withdrawFunds = (id, amount) => {
  return new Promise(async (resolve, reject) => {
    try {
      const customer = await Customer.findOne({ accNo: id });
      
      const snapshotOfCurrentBalance = customer.currentBalance - Number(amount);

      if (snapshotOfCurrentBalance < 0) {
        throw Error("Insufficient Funds!");
      }

      const updatedCustomer = await Customer.findOneAndUpdate(
        { accNo: id },
        {
          $inc: { currentBalance: -Number(amount) },
          $push: {
            transactions: {
              transactionType: "debit",
              transactionDetails: {
                transferredFrom: "Self",
                transferredTo: "Self",
                balance: snapshotOfCurrentBalance,
                amount: Number(amount),
              },
            },
          },
        },
        { new: true } // Return the updated document
      );

      resolve(updatedCustomer);
    } catch (error) {
      reject(error);
    }
  });
};
